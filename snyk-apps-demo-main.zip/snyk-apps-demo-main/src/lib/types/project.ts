export interface Project {
  id: string;
  attributes: {
    name: string;
    type: string;
    origin: string;
  };
}
