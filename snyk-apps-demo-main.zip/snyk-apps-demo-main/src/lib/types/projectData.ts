export interface ProjectData {
  id: string;
  name: string;
  type: string;
  origin: string;
}
