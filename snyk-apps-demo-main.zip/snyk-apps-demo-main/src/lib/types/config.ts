export const enum Config {
  ApiBase = 'api.base',
  AppBase = 'app.base',
  AuthURL = 'authorizationUrl',
  TokenURL = 'tokenUrl',
  Port = 'port',
}
