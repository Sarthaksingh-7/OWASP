export interface Org {
  id: string;
  name: string;
}
