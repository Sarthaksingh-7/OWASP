export const enum GrantType {
  RefreshToken = 'refresh_token',
  AuthorizationCode = 'authorization_code',
}
