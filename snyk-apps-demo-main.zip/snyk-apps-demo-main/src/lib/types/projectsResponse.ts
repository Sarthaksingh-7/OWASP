import { ProjectData } from './projectData';

export interface ProjectsResponse {
  projects: ProjectData[];
}
